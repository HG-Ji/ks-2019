package com.n2016548095.main.domain;

import com.n2016548095.main.repository.BasicRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class BasicTest {

    @Autowired
    private BasicRepository basicRepository;

    private Basic savedBasic;

    @Before
    public void init() {
        savedBasic = basicRepository.save(Basic.builder()
                .name("홍길동")
                .label("CEO")
                .email("hong@gmail.com")
                .phone("012-3456-789")
                .build());

        basicRepository.save(Basic.builder()
                .name("장길산")
                .label("CFO")
                .email("jang@gmail.com")
                .phone("123-456-7890")
                .build());

        basicRepository.save(Basic.builder()
                .name("춘향이")
                .label("CTO")
                .email("chun@gmail.com")
                .phone("234-567-8901")
                .build());
    }

    @Test
    public void testFindIDBasic() {
        Basic foundBasic = basicRepository.findById(savedBasic.getIdx()).orElse(null);
        assertThat(foundBasic.getIdx()).isEqualTo(savedBasic.getIdx());
    }

    @Test
    public void testFindAllBasic() {
        List<Basic> findAllBasic = basicRepository.findAllByName("홍길동");
        assertThat(findAllBasic.size()).isEqualTo(2);
    }

    @Test
    public void testFindTitleBasic() {
        Basic findTitleBasic = basicRepository.findFirstByName("홍길동");
        assertThat(findTitleBasic.getName()).isEqualTo("홍길동");
    }

    @Test
    public void testBasicFK() {
        Basic findTitleBasic = basicRepository.findFirstByName("홍길동");
        assertThat(findTitleBasic.getName()).isEqualTo("홍길동");
    }

}
