package com.n2016548095.main.domain;

import com.n2016548095.main.repository.ProfileRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class ProfileTest {

    @Autowired
    private ProfileRepository profileRepository;

    private Profile savedProfile;

    @Before
    public void init() {
        savedProfile = profileRepository.save(Profile.builder()
                .network("트위터")
                .username("@hong")
                .url("https://twitter/@home")
                .createdDate(LocalDateTime.now())
                .build());

        profileRepository.save(Profile.builder()
                .network("페이스북")
                .username("@home")
                .url("https://twitter/@home")
                .createdDate(LocalDateTime.now())
                .build());

        profileRepository.save(Profile.builder()
                .network("인스타그램")
                .username("@home")
                .url("https://twitter/@home")
                .createdDate(LocalDateTime.now())
                .build());
    }

    @Test
    public void testFindIDProfile() {
        Profile foundProfile = profileRepository.findById(savedProfile.getIdx()).orElse(null);
        assertThat(foundProfile.getIdx()).isEqualTo(savedProfile.getIdx());
    }

    @Test
    public void testFindAllProfile() {
        List<Profile> findAllProfile = profileRepository.findAllByNetwork("홍길동");
        assertThat(findAllProfile.size()).isEqualTo(2);
    }

    @Test
    public void testFindTitleProfile() {
        Profile findTitleProfile = profileRepository.findFirstByNetwork("트위터");
        assertThat(findTitleProfile.getNetwork()).isEqualTo("트위터");
    }

    @Test
    public void testProfileFK() {
        Profile findTitleProfile = profileRepository.findFirstByNetwork("홍길동");
        assertThat(findTitleProfile.getNetwork()).isEqualTo("홍길동");
    }

}
