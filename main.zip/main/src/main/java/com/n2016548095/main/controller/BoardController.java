package com.n2016548095.main.controller;

import com.n2016548095.main.domain.Basic;
import com.n2016548095.main.domain.Profile;
import com.n2016548095.main.repository.BasicRepository;
import com.n2016548095.main.repository.ProfileRepository;
import com.n2016548095.main.service.BasicService;
import com.n2016548095.main.service.ProfileService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import java.time.LocalDateTime;

@Controller
public class BoardController {

    private BasicService basicService;
    private ProfileService profileService;

    private BasicRepository basicRepository;
    private ProfileRepository profileRepository;

    public BoardController(BasicService basicService, ProfileService profileService, BasicRepository basicRepository, ProfileRepository profileRepository) {
        this.basicService = basicService;
        this.profileService = profileService;
        this.basicRepository = basicRepository;
        this.profileRepository = profileRepository;
    }

    @GetMapping("/")
    public String list(@PageableDefault Pageable pageable, Model model) {
        model.addAttribute("basicList", basicService.findBasicList(pageable));
        model.addAttribute("profileList", profileService.findProfileList(pageable));
        return "index";
    }

    @GetMapping("/basic/123/" + "{idx}")
    public String basicRead(@PathVariable Long idx, Model model) {
        model.addAttribute("basic", basicService.findBasicByIdx(idx));
        return "basicitem";
    }

    @GetMapping("/profile/35/" + "{idx}")
    public String profileRead(@PathVariable Long idx, Model model) {
        model.addAttribute("profile", profileService.findProfileByIdx(idx));
        return "profileitem";
    }


    @PostMapping("/basic/add")
    public String basicadd(Basic basic, Model model) {
        Basic saveBasic = basicRepository.save(basic);
        model.addAttribute("basic", basicService.findBasicByIdx(saveBasic.getIdx()));
        return "basicitem";
    }

    @PostMapping("/profile/add")
    public String profileadd(Profile profile, Model model) {
        profile.setCreatedDate(LocalDateTime.now());
        Profile saveProfile = profileRepository.save(profile);
        model.addAttribute("profile", profileService.findProfileByIdx(saveProfile.getIdx()));
        return "profileitem";
    }

    @GetMapping("/basic/new")
    public String form(Basic basic) {
        return "basicnew";
    }

    @GetMapping("/profile/new")
    public String form(Profile profile) {
        return "profilenew";
    }

}
